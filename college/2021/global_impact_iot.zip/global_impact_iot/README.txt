# Projeto Global Impact: Seleção de tomates resistentes

**Integrantes:** 

**Carlos Eduardo Hayashi 				- 2TDSF RM#85225**

**Danilo de Melo Arraes Pessoa				- 2TDSJ RM#82983**

**José Dijalbas Francisco dos Santos Bezerra 		- 2TDSJ RM#84254**

**Mike Vildoso Freire 					- 2TDSF RM#85455**

**Rodrigo de Almeida Barbosa 				- 2TDSA RM#85137**

**William José Rangon de Lima 				- 2TDSA RM#85970**

**Faculdade Paulista de Informática:**
**Turmas: 2TDSA/F/J**


## Objetivo / descrição do Projeto

Prever que tipo de tomates terão resistência ou não ao fungo, utilizando um modelo supervisionado de categorização de dados.

## Visualização do projeto com Google Colab

- Entre com sa conta google: https://colab.research.google.com

- Baixe o arquivo .Zip

- Extraia ele em algum lugar

- No Google Collab: Arquivo>Upload>Arraste ou Procure o caminho do arquivo>Play

  
## Link de vídeo demonstração

Adicione o link para assistir ao vídeo do projeto funcionando.

[https://youtu.be/oZBnhCjALsU]



